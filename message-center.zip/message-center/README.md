# 说明

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
npm run serve -- --mode xxx
```

### Compiles and minifies for production
```
npm run build
npm run build -- --mode xxx
```

### Run your tests
```
npm run test
```

### Lints and fixes files
```
npm run lint
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).
