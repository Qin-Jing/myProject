import common from './common';
import core from './core/vue';

common.init();
core.create(common.config);
