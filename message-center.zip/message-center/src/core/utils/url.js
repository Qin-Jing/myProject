import systemUtil from './system';

export default {
  generateSearchString(options) {

  }
};
