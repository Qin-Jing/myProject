export default {
  getBaseUrl() {
    return process.env.VUE_APP_BASE_URL;
  },
  getApaasUrl() {
    return process.env;
  }
};
