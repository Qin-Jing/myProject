export default {
  init() {
  }
};
