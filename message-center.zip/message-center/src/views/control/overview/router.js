export default [
  {
    path: 'overview',
    component: () => import('./overview')
  }
]