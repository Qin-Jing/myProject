<template>
  <div class="main-content">
    <slot />
  </div>
</template>

<script>
  export default {
    
  }
</script>

<style lang="scss">
  .main-content {
    padding: 20px;
  }
</style>
