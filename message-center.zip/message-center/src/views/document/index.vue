<template>
  <div class="apaas-short-message-document">
    <router-view />
  </div>
</template>

<script>
  export default {
    components: {},
    data() {
      return {}
    },
    computed: {},
    watch: {},
    created() {},
    methods: {}
  }
</script>

<style lang="scss">
  @import '~gui/style/theme/variables';
  // .apaas-short-message-document {
    // min-height: 100vh;
    // .el-container {
    //   height: auto;
    // }
    // .home-page-container {
    //   min-width: 1200px !important;
    //   min-height: calc(100vh - 164px);
    // }
    // .footer {
    //   background-color: #fff;
    // }
  // }
</style>