import Login from './index';

export default [
  {
    path: '/login',
    name: 'login',
    component: Login
  }
];
