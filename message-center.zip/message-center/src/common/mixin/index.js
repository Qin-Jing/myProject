import storeTool from './mixin';

export default {
  storeTool
};
