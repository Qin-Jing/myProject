export default [
  '/homepage',
  '/product',
  '/login',
  '/document',
  '/homepage/product',
  '/homepage/product/detail',
  '/homepage/product/apply',
  '/homepage/notification',
  '/homepage/notification/detail'
];
