export default {
  queryProtalInfo: {
    url: '/portal/home',
    method: 'GET',
    description: '获取门户网站信息'
  }
}